import argparse
import os
import random
from collections import Counter
from typing import List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, classification_report, f1_score
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModel, AutoTokenizer, get_linear_schedule_with_warmup


MODEL_NAME = "l3cube-pune/hindi-bert-v2"
WEIGHTS_SAVE_PATH = "hingbert_best.pt"
CONTEXT_PATH = "ContextGuard_K2_Ready.csv"
INDO_PATH = "Indo-HateSpeech_Dataset.csv"

LABELS = ("BENIGN", "WARN", "ESCALATE")
CLASS_RISK = torch.tensor([0.0, 0.5, 1.0], dtype=torch.float)
CLASS_WEIGHTS = torch.tensor([1.2, 0.6, 2.0], dtype=torch.float)
SPECIAL_TOKENS = {"additional_special_tokens": ["[CONTEXT]", "[TARGET]"]}


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def normalize_text(text) -> str:
    if pd.isna(text):
        return ""
    text = str(text).lower()
    leet_map = {"@": "a", "1": "i", "5": "s", "0": "o", "3": "e", "$": "s"}
    for src, dst in leet_map.items():
        text = text.replace(src, dst)
    return " ".join(text.split())


def score_to_label_id(score) -> Optional[int]:
    try:
        score = float(score)
    except (TypeError, ValueError):
        return None
    if score >= 0.75:
        return 2
    if score >= 0.25:
        return 1
    return 0


def indo_label_to_id(label) -> Optional[int]:
    label = str(label).strip().replace("'", "")
    mapping = {"HS0": 0, "HSN": 1, "HS1": 2}
    return mapping.get(label)


def load_contextguard_rows(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        return pd.DataFrame(columns=["text", "label", "source"])

    df = pd.read_csv(path)
    df = df.dropna(subset=["Input_Sequence", "Target_Score"]).copy()
    df["text"] = df["Input_Sequence"].map(normalize_text)
    df["label"] = df["Target_Score"].map(score_to_label_id)
    df["source"] = "contextguard_k2"
    return df[["text", "label", "source"]].dropna()


def load_indo_rows(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        return pd.DataFrame(columns=["text", "label", "source"])

    df = pd.read_csv(path)
    df = df.dropna(subset=["Comment", "Label"]).copy()
    df["comment"] = df["Comment"].map(normalize_text)
    df["text"] = "[CONTEXT] none [TARGET] " + df["comment"]
    df["label"] = df["Label"].map(indo_label_to_id)
    df["source"] = "indo_hatespeech"
    return df[["text", "label", "source"]].dropna()


def load_training_frame(context_path: str, indo_path: str) -> pd.DataFrame:
    frames = [load_contextguard_rows(context_path), load_indo_rows(indo_path)]
    df = pd.concat(frames, ignore_index=True)
    df = df[df["text"].str.len() > 0].copy()
    df["label"] = df["label"].astype(int)
    df = df.drop_duplicates(subset=["text", "label"]).reset_index(drop=True)
    if df.empty:
        raise ValueError("No training rows found. Check ContextGuard and Indo dataset paths.")
    return df


def oversample_training_frame(df: pd.DataFrame, seed: int) -> pd.DataFrame:
    counts = df["label"].value_counts()
    target_count = int(counts.max())
    parts = []
    for label_id, group in df.groupby("label"):
        replace = len(group) < target_count
        parts.append(group.sample(target_count, replace=replace, random_state=seed + int(label_id)))
    return pd.concat(parts, ignore_index=True).sample(frac=1, random_state=seed).reset_index(drop=True)


class TextDataset(Dataset):
    def __init__(self, texts: Sequence[str], labels: Sequence[int], tokenizer, max_length: int):
        self.texts = list(texts)
        self.labels = list(labels)
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, idx: int):
        encoded = self.tokenizer(
            self.texts[idx],
            padding="max_length",
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        )
        return {
            "input_ids": encoded["input_ids"].squeeze(0),
            "attention_mask": encoded["attention_mask"].squeeze(0),
            "labels": torch.tensor(self.labels[idx], dtype=torch.long),
        }


class HingBertClassifier(nn.Module):
    def __init__(
        self,
        model_name: str = MODEL_NAME,
        num_classes: int = 3,
        dropout: float = 0.3,
        unfreeze_last_n: int = 2,
    ):
        super().__init__()
        self.hingbert = AutoModel.from_pretrained(model_name)
        hidden_size = self.hingbert.config.hidden_size
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes),
        )
        self.freeze_encoder(unfreeze_last_n=unfreeze_last_n)

    def freeze_encoder(self, unfreeze_last_n: int = 2) -> None:
        for param in self.hingbert.parameters():
            param.requires_grad = False

        layers = getattr(getattr(self.hingbert, "encoder", None), "layer", None)
        if layers is not None:
            for layer in layers[-unfreeze_last_n:]:
                for param in layer.parameters():
                    param.requires_grad = True

        if hasattr(self.hingbert, "pooler") and self.hingbert.pooler is not None:
            for param in self.hingbert.pooler.parameters():
                param.requires_grad = True

    def forward(self, input_ids, attention_mask):
        output = self.hingbert(input_ids=input_ids, attention_mask=attention_mask)
        cls_embedding = output.last_hidden_state[:, 0, :]
        return self.classifier(cls_embedding)


def run_epoch(model, loader, optimizer, scheduler, criterion, device: str, train: bool) -> Tuple[float, float, float]:
    model.train(train)
    losses = []
    all_preds = []
    all_labels = []

    for batch in loader:
        input_ids = batch["input_ids"].to(device)
        attention_mask = batch["attention_mask"].to(device)
        labels = batch["labels"].to(device)

        with torch.set_grad_enabled(train):
            logits = model(input_ids=input_ids, attention_mask=attention_mask)
            loss = criterion(logits, labels)

            if train:
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                scheduler.step()

        preds = torch.argmax(logits, dim=-1)
        losses.append(loss.item())
        all_preds.extend(preds.detach().cpu().tolist())
        all_labels.extend(labels.detach().cpu().tolist())

    return (
        float(np.mean(losses)),
        accuracy_score(all_labels, all_preds),
        f1_score(all_labels, all_preds, average="macro", zero_division=0),
    )


def save_checkpoint(model: HingBertClassifier, path: str) -> None:
    torch.save(model.state_dict(), path)


def train(args) -> None:
    seed_everything(args.seed)
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"

    df = load_training_frame(args.context_path, args.indo_path)
    print(f"Loaded {len(df)} rows from ContextGuard + Indo datasets.")
    print("Original label distribution:", dict(Counter(df["label"])))

    train_df, val_df = train_test_split(
        df,
        test_size=args.val_size,
        random_state=args.seed,
        stratify=df["label"],
    )
    if args.oversample:
        train_df = oversample_training_frame(train_df, args.seed)
    print("Train label distribution:", dict(Counter(train_df["label"])))
    print("Val label distribution:", dict(Counter(val_df["label"])))

    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    tokenizer.add_special_tokens(SPECIAL_TOKENS)
    tokenizer.truncation_side = "left"

    model = HingBertClassifier(
        model_name=args.model_name,
        num_classes=len(LABELS),
        dropout=args.dropout,
        unfreeze_last_n=args.unfreeze_last_n,
    ).to(device)
    model.hingbert.resize_token_embeddings(len(tokenizer))

    train_ds = TextDataset(train_df["text"], train_df["label"], tokenizer, args.max_length)
    val_ds = TextDataset(val_df["text"], val_df["label"], tokenizer, args.max_length)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size * 2, shuffle=False)

    class_weights = CLASS_WEIGHTS.to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )
    total_steps = len(train_loader) * args.epochs
    warmup_steps = int(total_steps * args.warmup_ratio)
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)

    best_macro_f1 = -1.0
    best_epoch = 0
    patience_left = args.patience

    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc, train_f1 = run_epoch(
            model, train_loader, optimizer, scheduler, criterion, device, train=True
        )
        val_loss, val_acc, val_f1 = run_epoch(
            model, val_loader, optimizer, scheduler, criterion, device, train=False
        )
        print(
            f"epoch={epoch} train_loss={train_loss:.4f} train_acc={train_acc:.4f} "
            f"train_macro_f1={train_f1:.4f} val_loss={val_loss:.4f} "
            f"val_acc={val_acc:.4f} val_macro_f1={val_f1:.4f}"
        )

        if val_f1 > best_macro_f1:
            best_macro_f1 = val_f1
            best_epoch = epoch
            patience_left = args.patience
            save_checkpoint(model, args.weights_save_path)
            tokenizer.save_pretrained(args.tokenizer_save_dir)
            print(f"Saved best checkpoint to {args.weights_save_path}")
        else:
            patience_left -= 1
            if patience_left <= 0:
                print("Early stopping triggered.")
                break

    model.load_state_dict(torch.load(args.weights_save_path, map_location=device))
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for batch in val_loader:
            logits = model(
                input_ids=batch["input_ids"].to(device),
                attention_mask=batch["attention_mask"].to(device),
            )
            all_preds.extend(torch.argmax(logits, dim=-1).cpu().tolist())
            all_labels.extend(batch["labels"].tolist())

    print(f"Best epoch: {best_epoch}, best val macro-F1: {best_macro_f1:.4f}")
    print(classification_report(all_labels, all_preds, target_names=LABELS, zero_division=0))


class HingBertModerator:
    def __init__(
        self,
        weights_path: str = WEIGHTS_SAVE_PATH,
        model_name: str = MODEL_NAME,
        tokenizer_path: Optional[str] = None,
        device: Optional[str] = None,
        max_length: int = 128,
    ):
        if not os.path.exists(weights_path):
            raise FileNotFoundError(f"HingBERT weights not found: {weights_path}")

        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.max_length = max_length
        tokenizer_source = tokenizer_path if tokenizer_path and os.path.exists(tokenizer_path) else model_name
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_source)
        self.tokenizer.add_special_tokens(SPECIAL_TOKENS)
        self.tokenizer.truncation_side = "left"
        self.model = HingBertClassifier(model_name=model_name, num_classes=len(LABELS)).to(self.device)
        self.model.hingbert.resize_token_embeddings(len(self.tokenizer))

        state_dict = torch.load(weights_path, map_location=self.device)
        if isinstance(state_dict, dict) and "state_dict" in state_dict:
            state_dict = state_dict["state_dict"]
        elif isinstance(state_dict, dict) and "model_state_dict" in state_dict:
            state_dict = state_dict["model_state_dict"]
        if isinstance(state_dict, dict) and any(key.startswith("module.") for key in state_dict):
            state_dict = {
                key[7:] if key.startswith("module.") else key: value
                for key, value in state_dict.items()
            }
        self.model.load_state_dict(state_dict)
        self.model.eval()

    def predict(self, texts: Sequence[str]) -> List[Tuple[str, float, List[float]]]:
        if not texts:
            return []

        formatted = [
            text if "[TARGET]" in text else f"[CONTEXT] none [TARGET] {text}"
            for text in texts
        ]
        inputs = self.tokenizer(
            formatted,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        ).to(self.device)

        # Some BERT tokenizers emit token_type_ids, but HingBertClassifier
        # intentionally accepts only the tensors used by its forward method.
        model_inputs = {
            name: inputs[name] for name in ("input_ids", "attention_mask") if name in inputs
        }
        with torch.no_grad():
            logits = self.model(**model_inputs)
            probs = torch.softmax(logits, dim=-1)
            pred_ids = torch.argmax(probs, dim=-1)
            risk_scores = torch.sum(probs.cpu() * CLASS_RISK, dim=-1)

        probs_list = probs.cpu().tolist()
        return [
            (LABELS[pred_id.item()], round(risk_scores[i].item(), 3), probs_list[i])
            for i, pred_id in enumerate(pred_ids)
        ]


def parse_args():
    parser = argparse.ArgumentParser(description="Train HingBERT for ContextGuard moderation.")
    parser.add_argument("--context-path", default=CONTEXT_PATH)
    parser.add_argument("--indo-path", default=INDO_PATH)
    parser.add_argument("--model-name", default=MODEL_NAME)
    parser.add_argument("--weights-save-path", default=WEIGHTS_SAVE_PATH)
    parser.add_argument("--tokenizer-save-dir", default="hingbert_tokenizer")
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--max-length", type=int, default=128)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--warmup-ratio", type=float, default=0.1)
    parser.add_argument("--dropout", type=float, default=0.3)
    parser.add_argument("--val-size", type=float, default=0.15)
    parser.add_argument("--patience", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--unfreeze-last-n", type=int, default=2)
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--no-oversample", dest="oversample", action="store_false")
    parser.set_defaults(oversample=True)
    return parser.parse_args()


if __name__ == "__main__":
    train(parse_args())
