#!/usr/bin/env python3
"""FastAPI service for the ContextGuard v4 SFT + GRPO adapter stack.

Start from ``/home/rl_web``::

    uvicorn contextguard_grpo_api:app --host 0.0.0.0 --port 8000

The model is loaded once during startup.  GPU generation is serialized because
the service owns one local 8B model instance.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import os
from pathlib import Path
import re
import threading
from typing import Literal

import torch
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from peft import PeftModel
from pydantic import BaseModel, Field
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from content_classifier import ContentClassificationResult
from toxicity_service import ToxicityService


ROOT = Path(__file__).resolve().parent
BASE_MODEL = os.environ.get("CONTEXTGUARD_BASE_MODEL", "mlabonne/Meta-Llama-3.1-8B-Instruct-abliterated")
SFT_ADAPTER = Path(os.environ.get(
    "CONTEXTGUARD_SFT_ADAPTER", str(ROOT / "contextguard_v4_llama31_8b_abliterated_sft")
))
GRPO_ADAPTER = Path(os.environ.get("CONTEXTGUARD_GRPO_ADAPTER", str(ROOT / "contextguard_grpo_outputs")))
MAX_NEW_TOKENS = int(os.environ.get("CONTEXTGUARD_MAX_NEW_TOKENS", "512"))
MAX_CONTEXT_COMMENTS = 5
MAX_COMMENT_CHARS = 8_000
# Set this when hosting behind a path-based reverse proxy, e.g.
# CONTEXTGUARD_ROOT_PATH=/proxy/8001 on Jarvis Labs.
ROOT_PATH = os.environ.get("CONTEXTGUARD_ROOT_PATH", "").rstrip("/")

SYSTEM_PROMPT = (
    "You are ContextGuard, an AI moderation system. Analyze the Hinglish text and classify it into "
    "BENIGN, WARN, or ESCALATE. Do NOT use tool calls. Do NOT output <tool_call>. "
    "Provide your reasoning inside <reasoning> tags, followed by your decision inside <action> tags."
)
RESPONSE_PATTERN = re.compile(
    r"\A\s*<reasoning>(?P<reasoning>.*?)</reasoning>\s*"
    r"<action>(?P<action>BENIGN|WARN|ESCALATE)</action>\s*\Z",
    flags=re.DOTALL,
)
REASONING_PATTERN = re.compile(r"<reasoning>\s*(?P<reasoning>.*?)\s*</reasoning>", flags=re.DOTALL)
ACTION_PATTERN = re.compile(r"<action>\s*(?P<action>BENIGN|WARN|ESCALATE)\s*</action>")


class ModerationRequest(BaseModel):
    """The target is moderated in the optional context of up to five comments."""

    target_comment: str = Field(min_length=1, max_length=MAX_COMMENT_CHARS)
    previous_comments: list[str] = Field(default_factory=list, max_length=MAX_CONTEXT_COMMENTS)


class ModerationResponse(BaseModel):
    status: Literal["benign", "needs_context", "moderated"]
    action: Literal["BENIGN", "WARN", "ESCALATE"] | None = None
    reasoning: str | None = None
    classifier_prediction: Literal["BENIGN", "WARN", "ESCALATE"]
    classifier_confidence: float
    routed_model: str
    detected_language: str


class HealthResponse(BaseModel):
    status: Literal["ready", "unavailable"]
    detail: str | None = None


class _DisabledContentClassifier:
    """Avoid loading the unrelated BART content model in this routing path."""

    def classify(self, text: str) -> ContentClassificationResult:
        del text
        return ContentClassificationResult(None, None, None, "disabled")


def build_prompt(previous_comments: list[str], target_comment: str) -> str:
    """Use the v4 GRPO prompt format, adding context only when supplied."""
    cleaned_context = [comment.strip() for comment in previous_comments if comment.strip()]
    history = ""
    if cleaned_context:
        joined = "\n".join(f"Comment {index}: {comment}" for index, comment in enumerate(cleaned_context, 1))
        history = f"\n\n[Previous Comments]\n{joined}"
    return (
        f"{SYSTEM_PROMPT}{history}\n\n[Target Comment]\n{target_comment.strip()}\n\n"
        "Provide your <reasoning> and <action>."
    )


def parse_response(output: str) -> tuple[str, str]:
    """Extract one valid response, tolerating harmless model wrapper text.

    The SFT/GRPO model is trained to emit the tags, but decoder artifacts or a
    brief leading sentence should not turn an otherwise valid moderation result
    into a service failure.  Multiple action tags remain invalid.
    """
    match = RESPONSE_PATTERN.fullmatch(output)
    if match is not None and match.group("reasoning").strip():
        return match.group("reasoning").strip(), match.group("action")
    reasonings = REASONING_PATTERN.findall(output)
    actions = ACTION_PATTERN.findall(output)
    if len(reasonings) != 1 or len(actions) != 1 or not reasonings[0].strip():
        raise ValueError("Model output did not meet the required reasoning/action XML contract.")
    return reasonings[0].strip(), actions[0]


class ContextGuardGRPO:
    """Process-lifetime 4-bit model service; generation is not thread-safe."""

    def __init__(self) -> None:
        self.tokenizer = None
        self.model = None
        self._lock = threading.Lock()
        self._load_lock = threading.Lock()

    def load(self) -> None:
        """Load once, only when a classifier-flagged request has context."""
        with self._load_lock:
            if self.model is not None and self.tokenizer is not None:
                return
            if not torch.cuda.is_available():
                raise RuntimeError("ContextGuard GRPO API requires a CUDA GPU.")
            for name, directory in (("SFT", SFT_ADAPTER), ("GRPO", GRPO_ADAPTER)):
                if not (directory / "adapter_config.json").is_file():
                    raise FileNotFoundError(f"{name} adapter is missing adapter_config.json: {directory}")

            token = os.environ.get("HF_TOKEN")
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            tokenizer = AutoTokenizer.from_pretrained(GRPO_ADAPTER, use_fast=True, token=token)
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            model = AutoModelForCausalLM.from_pretrained(
                BASE_MODEL,
                quantization_config=BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_use_double_quant=True,
                    bnb_4bit_compute_dtype=dtype,
                ),
                torch_dtype=dtype,
                device_map={"": 0},
                token=token,
            )
            model = PeftModel.from_pretrained(model, SFT_ADAPTER, adapter_name="default")
            model.load_adapter(GRPO_ADAPTER, adapter_name="grpo")
            # GRPO was trained with frozen SFT + trainable GRPO adapters active.
            model.base_model.set_adapter(["default", "grpo"], inference_mode=True)
            model.eval()
            self.tokenizer, self.model = tokenizer, model

    def moderate(self, previous_comments: list[str], target_comment: str) -> tuple[str, str]:
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Model is not loaded.")
        prompt = build_prompt(previous_comments, target_comment)
        with self._lock, torch.inference_mode():
            device = self.model.get_input_embeddings().weight.device
            inputs = self.tokenizer(prompt, return_tensors="pt", add_special_tokens=False).to(device)
            generated = self.model.generate(
                **inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=False,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
            output = self.tokenizer.decode(
                generated[0, inputs["input_ids"].shape[1]:], skip_special_tokens=False,
            )
        return parse_response(output)


moderator = ContextGuardGRPO()
# ``ToxicityService`` owns the FastText router and lazily loads the selected
# English BERT or HingBERT classifier.  Content classification is deliberately
# disabled: it is not part of the router -> BERT -> GRPO decision flow.
toxicity_router = ToxicityService(content_classifier=_DisabledContentClassifier())


@asynccontextmanager
async def lifespan(app: FastAPI):
    # The lightweight router/BERT stage is lazy in ToxicityService.  Defer the
    # 8B GRPO model too: benign requests and requests without context never
    # need to occupy its GPU memory.
    app.state.ready = False
    app.state.load_error = None
    app.state.ready = True
    yield
    moderator.model = None
    moderator.tokenizer = None
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


app = FastAPI(
    title="ContextGuard v4 GRPO API",
    version="1.0.0",
    lifespan=lifespan,
    root_path=ROOT_PATH,
)


@app.get("/", include_in_schema=False)
async def root(request: Request) -> RedirectResponse:
    """Open the browser moderation UI when the server URL is visited."""
    return RedirectResponse(url=f"{request.scope.get('root_path', '')}/ui")


@app.get("/ui", include_in_schema=False, response_class=HTMLResponse)
async def browser_ui(request: Request) -> HTMLResponse:
    """Small dependency-free UI for reverse proxies that cannot expose Streamlit."""
    page = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>ContextGuard</title><style>
body { font: 16px system-ui, sans-serif; max-width: 760px; margin: 48px auto; padding: 0 20px; color: #172033; }
textarea { box-sizing: border-box; width: 100%; min-height: 125px; padding: 12px; font: inherit; }
button { background:#2563eb; border:0; border-radius:6px; color:#fff; cursor:pointer; font:inherit; margin:16px 0; padding:10px 16px; }
#context { display:none; } #result { border-radius:7px; line-height:1.5; padding:14px; white-space:pre-wrap; }
.benign { background:#dcfce7; } .warn { background:#fef3c7; } .escalate { background:#fee2e2; } .error { background:#fee2e2; }
</style></head><body><h1>🛡️ ContextGuard</h1>
<p>Enter a target comment. The language router and BERT model screen it first; context is requested only when it is flagged.</p>
<p><small>This Jarvis-compatible UI uses a GET request because the hosted proxy rejects browser POST requests. Do not enter sensitive personal data here; it may appear in browser/proxy URL logs.</small></p>
<label for="target"><b>Target comment</b></label><textarea id="target" placeholder="Type a comment to moderate…"></textarea>
<div id="context"><label for="previous"><b>Previous comments</b> (one per line, up to five)</label>
<textarea id="previous" placeholder="First previous comment&#10;Second previous comment"></textarea></div>
<button id="submit" type="button">Check comment</button><div id="result" hidden></div>
<script>
// Derive the API address from the current browser path, preserving reverse
// proxy prefixes such as Jarvis /proxy/8001.
const apiUrl = window.location.pathname.replace(/\/ui\/?$/, '/v1/moderate'); let needsContext = false;
const target = document.getElementById('target'), previous = document.getElementById('previous');
const context = document.getElementById('context'), result = document.getElementById('result'), submit = document.getElementById('submit');
function show(message, cls) { result.hidden=false; result.className=cls; result.textContent=message; }
submit.addEventListener('click', async () => {
  const text = target.value.trim(); if (!text) return show('Enter a target comment first.', 'error');
  const comments = needsContext ? previous.value.split('\\n').map(x=>x.trim()).filter(Boolean).slice(-5) : [];
  if (needsContext && !comments.length) return show('Enter at least one previous comment.', 'error');
  submit.disabled=true; show('Checking comment…', 'warn');
  try {
    const query = new URLSearchParams({target_comment:text});
    comments.forEach(comment => query.append('previous_comments', comment));
    const response = await fetch(`${apiUrl}?${query.toString()}`);
    const raw = await response.text(); let data;
    try { data = JSON.parse(raw); } catch (_) { throw new Error(`HTTP ${response.status}: proxy returned non-JSON (${raw.slice(0, 180)})`); }
    if (!response.ok) throw new Error(data.detail || `HTTP ${response.status}: request failed`);
    const classifier = `BERT: ${data.classifier_prediction} (${Math.round(data.classifier_confidence*100)}%) · ${data.routed_model}`;
    if (data.status === 'benign') { needsContext=false; context.style.display='none'; show(`Action: BENIGN\n${classifier}\n\nGRPO was not called.`, 'benign'); }
    else if (data.status === 'needs_context') { needsContext=true; context.style.display='block'; show(`This target was flagged for review.\n${classifier}\n\nAdd prior comments and click Check comment again.`, 'warn'); }
    else { needsContext=false; context.style.display='none'; const cls=data.action==='ESCALATE'?'escalate':data.action==='WARN'?'warn':'benign'; show(`Action: ${data.action}\n${classifier}\n\nReasoning:\n${data.reasoning}`, cls); }
  } catch (error) { show(`Error: ${error.message}`, 'error'); } finally { submit.disabled=false; }
});
</script></body></html>"""
    return HTMLResponse(page)


@app.get("/health", response_model=HealthResponse)
async def health(request: Request) -> HealthResponse:
    if request.app.state.ready:
        return HealthResponse(status="ready")
    return HealthResponse(status="unavailable", detail=request.app.state.load_error)


@app.post("/v1/moderate", response_model=ModerationResponse)
async def moderate(payload: ModerationRequest, request: Request) -> ModerationResponse:
    if not request.app.state.ready:
        raise HTTPException(status_code=503, detail="ContextGuard GRPO model is unavailable.")
    try:
        classifier = await asyncio.to_thread(toxicity_router.classify, payload.target_comment)
    except Exception as exc:
        # Do not bypass the first-stage classifier if it is unavailable.
        raise HTTPException(status_code=503, detail="ContextGuard classifier is unavailable.") from exc

    classifier_fields = dict(
        classifier_prediction=classifier.prediction,
        classifier_confidence=round(classifier.confidence, 4),
        routed_model=classifier.model_used,
        detected_language=classifier.detected_language,
    )
    # BENIGN at the BERT stage never spends GRPO generation capacity.  The
    # response makes its non-GRPO source explicit by omitting reasoning.
    if classifier.prediction == "BENIGN":
        return ModerationResponse(status="benign", action="BENIGN", **classifier_fields)

    # WARN/ESCALATE needs conversational evidence.  The client should collect
    # up to five prior comments and resubmit the same target with that context.
    if not any(comment.strip() for comment in payload.previous_comments):
        return ModerationResponse(status="needs_context", **classifier_fields)

    try:
        await asyncio.to_thread(moderator.load)
        reasoning, action = await asyncio.to_thread(
            moderator.moderate, payload.previous_comments, payload.target_comment,
        )
    except ValueError as exc:
        # The model completed but violated the response contract; do not invent
        # an action from malformed text.
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="ContextGuard generation failed.") from exc
    return ModerationResponse(status="moderated", reasoning=reasoning, action=action, **classifier_fields)


@app.get("/v1/moderate", response_model=ModerationResponse, include_in_schema=False)
async def moderate_browser_fallback(
    request: Request,
    target_comment: str = Query(min_length=1, max_length=MAX_COMMENT_CHARS),
    previous_comments: list[str] = Query(default=[]),
) -> ModerationResponse:
    """GET fallback for the built-in UI when a reverse proxy rejects POST.

    Use the documented POST endpoint for production API clients: query strings
    can be recorded by browser history and proxy logs.
    """
    if len(previous_comments) > MAX_CONTEXT_COMMENTS:
        raise HTTPException(status_code=422, detail="At most five previous comments are allowed.")
    return await moderate(
        ModerationRequest(target_comment=target_comment, previous_comments=previous_comments), request,
    )
