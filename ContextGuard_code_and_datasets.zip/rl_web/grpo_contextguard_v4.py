#!/usr/bin/env python3
"""GRPO alignment for ContextGuard's tagged reasoning/action response format.

The input JSONL must contain one object per line::

    {"prompt": "...", "target_action": "BENIGN"}

``prompt`` is passed to the model verbatim.  It should therefore already
contain the system policy, the preceding comments, and the target comment.
The script loads the frozen SFT LoRA alongside a *new*, trainable QLoRA
adapter for GRPO.  Keeping the adapters stacked avoids the large transient
memory allocation caused by merging an 8B adapter into 4-bit weights on a
24 GB GPU.  The resulting adapter must be loaded alongside the SFT warm start
recorded in its metadata.

Example (24 GB GPU)::

    python grpo_contextguard_v4.py \
      --sft_adapter ./sft_outputs \
      --dataset ./contextguard_grpo_data.jsonl \
      --output_dir ./contextguard_grpo_outputs

Requires compatible versions of torch, transformers, peft, bitsandbytes,
datasets and TRL (with ``GRPOTrainer``).  ``--use_unsloth`` is optional; it
uses Unsloth for the initial 4-bit model and new LoRA adapter when installed.
"""
from __future__ import annotations

import argparse
import inspect
import json
import os
import re
from pathlib import Path
from typing import Any, Iterable

import torch
from datasets import Dataset
from peft import LoraConfig, PeftModel, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, set_seed
from transformers.trainer_utils import get_last_checkpoint
from trl import GRPOConfig, GRPOTrainer


ROOT = Path(__file__).resolve().parent
# Must match ``adapter_config.json`` of the v4 SFT warm-start adapter.
DEFAULT_BASE_MODEL = "mlabonne/Meta-Llama-3.1-8B-Instruct-abliterated"
VALID_ACTIONS = frozenset({"BENIGN", "WARN", "ESCALATE"})

# Anchors deliberately reject commentary before/after the XML contract,
# duplicate tags, a missing closing tag, and lower-case/near-miss actions.
RESPONSE_PATTERN = re.compile(
    r"\A\s*<reasoning>(?P<reasoning>.*?)</reasoning>\s*"
    r"<action>(?P<action>BENIGN|WARN|ESCALATE)</action>\s*\Z",
    flags=re.DOTALL,
)


def _completion_text(completion: Any) -> str:
    """Normalise both plain and conversational TRL completion representations."""
    if isinstance(completion, str):
        return completion
    if isinstance(completion, list) and completion and isinstance(completion[-1], dict):
        content = completion[-1].get("content", "")
        return content if isinstance(content, str) else ""
    return ""


def parse_strict_response(completion: Any) -> tuple[str, str] | None:
    """Return ``(reasoning, action)`` only for one exact valid response."""
    match = RESPONSE_PATTERN.fullmatch(_completion_text(completion))
    if match is None or not match.group("reasoning").strip():
        return None
    return match.group("reasoning"), match.group("action")


# These are module-level methods because TRL invokes reward callables directly.
def format_reward(completions: Iterable[Any], **_: Any) -> list[float]:
    """Give +1 only to exactly ``<reasoning>...</reasoning><action>...</action>``."""
    return [1.0 if parse_strict_response(completion) is not None else -1.0 for completion in completions]


def accuracy_reward(completions: Iterable[Any], target_action: Iterable[str], **_: Any) -> list[float]:
    """Give +2 when the strictly parsed action equals the dataset label."""
    rewards: list[float] = []
    for completion, target in zip(completions, target_action):
        parsed = parse_strict_response(completion)
        rewards.append(2.0 if parsed is not None and parsed[1] == target else 0.0)
    return rewards


def conciseness_reward(
    completions: Iterable[Any], *, free_reasoning_tokens: int = 150, **_: Any
) -> list[float]:
    """Apply a small, capped penalty after the first 150 whitespace tokens.

    It is intentionally weak: correctness and the response contract remain
    much more important than making an explanation artificially short.
    """
    rewards: list[float] = []
    for completion in completions:
        parsed = parse_strict_response(completion)
        if parsed is None:
            rewards.append(0.0)
            continue
        excess = max(0, len(parsed[0].split()) - free_reasoning_tokens)
        rewards.append(-min(0.50, 0.01 * excess))
    return rewards


def load_dataset(dataset_path: Path) -> Dataset:
    """Read and validate the prompt-only GRPO dataset before allocating a GPU."""
    if not dataset_path.is_file():
        raise FileNotFoundError(f"Dataset does not exist: {dataset_path}")
    rows: list[dict[str, str]] = []
    with dataset_path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{dataset_path}:{line_number}: invalid JSON") from exc
            prompt, action = row.get("prompt"), row.get("target_action")
            if not isinstance(prompt, str) or not prompt.strip():
                raise ValueError(f"{dataset_path}:{line_number}: prompt must be a non-empty string")
            if action not in VALID_ACTIONS:
                raise ValueError(
                    f"{dataset_path}:{line_number}: target_action must be one of {sorted(VALID_ACTIONS)}"
                )
            rows.append({"prompt": prompt, "target_action": action})
    if not rows:
        raise ValueError(f"{dataset_path} contains no training rows")
    return Dataset.from_list(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base_model", default=DEFAULT_BASE_MODEL)
    parser.add_argument("--sft_adapter", type=Path, default=ROOT / "sft_outputs")
    parser.add_argument("--dataset", type=Path, default=ROOT / "contextguard_grpo_data.jsonl")
    parser.add_argument("--output_dir", type=Path, default=ROOT / "contextguard_grpo_outputs")
    parser.add_argument("--resume_from_checkpoint", type=Path)
    parser.add_argument("--use_unsloth", action="store_true", help="Use Unsloth if it is installed.")
    parser.add_argument("--num_generations", type=int, choices=(4, 8), default=4)
    parser.add_argument("--max_prompt_length", type=int, default=1536)
    # TRL's generation budget; equivalent to model.generate(max_new_tokens=512).
    parser.add_argument("--max_completion_length", type=int, default=512)
    parser.add_argument("--epochs", type=float, default=1.0)
    parser.add_argument("--learning_rate", type=float, default=5e-6)
    # TRL requires the (single-process) rollout batch to be divisible by G.
    # Four prompts x four completions is the conservative no-vLLM setting.
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=2)
    parser.add_argument("--beta", type=float, default=0.04, help="KL penalty against the SFT warm start.")
    parser.add_argument("--seed", type=int, default=20261016)
    return parser.parse_args()


def load_model_and_tokenizer(args: argparse.Namespace):
    """Load frozen SFT LoRA plus a separate trainable GRPO LoRA in 4-bit."""
    if not args.sft_adapter.is_dir():
        raise FileNotFoundError(f"SFT adapter directory does not exist: {args.sft_adapter}")
    compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    token = os.environ.get("HF_TOKEN")
    tokenizer = AutoTokenizer.from_pretrained(args.base_model, use_fast=True, token=token)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"  # Required for efficient batched generation.

    if args.use_unsloth:
        try:
            from unsloth import FastLanguageModel
        except ImportError as exc:
            raise RuntimeError("--use_unsloth requires `pip install unsloth`.") from exc
        model, _ = FastLanguageModel.from_pretrained(
            model_name=args.base_model,
            max_seq_length=args.max_prompt_length + args.max_completion_length,
            dtype=None,
            load_in_4bit=True,
            token=token,
        )
    else:
        quantization = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=compute_dtype,
        )
        model = AutoModelForCausalLM.from_pretrained(
            args.base_model,
            quantization_config=quantization,
            torch_dtype=compute_dtype,
            device_map={"": 0},
            token=token,
        )

    model.config.pad_token_id = tokenizer.pad_token_id
    model.config.use_cache = False
    model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)
    # PEFT's normal wrapper permits only one active adapter, but its underlying
    # LoRA tuner supports a list.  Retain the SFT adapter as ``default`` and
    # add an independent ``grpo`` adapter; only the latter receives gradients.
    model = PeftModel.from_pretrained(
        model, str(args.sft_adapter), adapter_name="default", is_trainable=False,
    )
    model.add_adapter("grpo", LoraConfig(
        r=16, lora_alpha=32, lora_dropout=0.05, bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    ))
    model.base_model.set_adapter(["default", "grpo"], inference_mode=False)
    for name, parameter in model.named_parameters():
        if ".default." in name:
            parameter.requires_grad_(False)
        elif ".grpo." in name:
            parameter.requires_grad_(True)
    model.print_trainable_parameters()
    return model, tokenizer, compute_dtype


def validate_prompt_lengths(dataset: Dataset, tokenizer, max_prompt_length: int) -> None:
    """Enforce the prompt budget on TRL releases without ``max_prompt_length``.

    TRL 1.14 removed that configuration field.  Failing early is safer than
    silently truncating either the policy at the start or the target comment at
    the end of a moderation prompt.
    """
    longest_index, longest_length = max(
        (
            (index, len(tokenizer(example["prompt"], add_special_tokens=False)["input_ids"]))
            for index, example in enumerate(dataset)
        ),
        key=lambda pair: pair[1],
    )
    if longest_length > max_prompt_length:
        raise ValueError(
            f"Prompt {longest_index} is {longest_length} tokens, above --max_prompt_length "
            f"({max_prompt_length}). Increase the limit only if the GPU has room, or shorten the prompt."
        )


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("GRPO QLoRA training requires a CUDA GPU.")
    if args.max_prompt_length <= 0 or args.max_completion_length <= 0:
        raise ValueError("Maximum prompt and completion lengths must be positive.")
    if args.batch_size < args.num_generations or args.batch_size % args.num_generations:
        raise ValueError(
            "Without a separate vLLM generation server, batch_size must be a multiple of "
            "num_generations (for example, --batch_size 4 --num_generations 4)."
        )
    if args.output_dir.exists() and any(args.output_dir.iterdir()) and not args.resume_from_checkpoint:
        raise FileExistsError("Output directory is non-empty; pass --resume_from_checkpoint or choose a new directory.")

    set_seed(args.seed)
    dataset = load_dataset(args.dataset)
    model, tokenizer, compute_dtype = load_model_and_tokenizer(args)
    validate_prompt_lengths(dataset, tokenizer, args.max_prompt_length)
    checkpoint = str(args.resume_from_checkpoint) if args.resume_from_checkpoint else (
        get_last_checkpoint(str(args.output_dir)) if args.output_dir.exists() else None
    )
    if checkpoint is not None and not (Path(checkpoint) / "trainer_state.json").is_file():
        raise FileNotFoundError(f"Not a valid Trainer checkpoint: {checkpoint}")

    # G=4 is the safest 24 GB default.  G=8 is exposed for short prompts on a
    # 4090/A10G after confirming peak memory headroom.
    grpo_kwargs: dict[str, Any] = dict(
        output_dir=str(args.output_dir),
        num_train_epochs=args.epochs,
        learning_rate=args.learning_rate,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        num_generations=args.num_generations,
        max_completion_length=args.max_completion_length,
        beta=args.beta,
        temperature=0.8,
        gradient_checkpointing=True,
        bf16=compute_dtype == torch.bfloat16,
        fp16=compute_dtype == torch.float16,
        logging_steps=5,
        save_strategy="steps",
        save_steps=100,
        save_total_limit=2,
        report_to="none",
        seed=args.seed,
        data_seed=args.seed,
    )
    # Older TRL releases support native prompt truncation; TRL 1.14+ does not.
    # ``validate_prompt_lengths`` above preserves the configured budget on both.
    if "max_prompt_length" in inspect.signature(GRPOConfig).parameters:
        grpo_kwargs["max_prompt_length"] = args.max_prompt_length
    training_args = GRPOConfig(**grpo_kwargs)
    trainer = GRPOTrainer(
        model=model,
        reward_funcs=[format_reward, accuracy_reward, conciseness_reward],
        args=training_args,
        train_dataset=dataset,
        processing_class=tokenizer,
    )
    trainer.train(resume_from_checkpoint=checkpoint)
    trainer.save_model(str(args.output_dir))
    tokenizer.save_pretrained(str(args.output_dir))
    (args.output_dir / "run_metadata.json").write_text(json.dumps({
        "base_model": args.base_model,
        "sft_adapter": str(args.sft_adapter.resolve()),
        "grpo_adapter_name": "grpo",
        "dataset": str(args.dataset.resolve()),
        "train_examples": len(dataset),
        "num_generations": args.num_generations,
        "beta": args.beta,
        "seed": args.seed,
    }, indent=2) + "\n", encoding="utf-8")
    print(f"Saved GRPO LoRA adapter and tokenizer to {args.output_dir}")


if __name__ == "__main__":
    main()
