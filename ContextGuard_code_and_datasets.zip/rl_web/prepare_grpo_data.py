#!/usr/bin/env python3
"""Convert ContextGuard's v4 SFT JSONL into prompt-only GRPO JSONL.

The SFT corpus contains a system instruction, one target user comment, and an
annotated assistant response.  It has no previous-comment history, so this
converter deliberately renders the user text as the single ``[Target Comment]``
in the GRPO prompt.  Later multi-turn data can add a ``[Previous Comments]``
section before that target without changing the GRPO trainer's input schema.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VALID_ACTIONS = frozenset({"BENIGN", "WARN", "ESCALATE"})
ACTION_PATTERN = re.compile(r"<action>\s*(BENIGN|WARN|ESCALATE)\s*</action>")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input_file", type=Path, default=ROOT / "contextguard_sft_dataset_v4_ready.jsonl",
        help="Source SFT JSONL containing system, user, assistant messages.",
    )
    parser.add_argument(
        "--output_file", type=Path, default=ROOT / "contextguard_grpo_data.jsonl",
        help="Destination prompt-only GRPO JSONL.",
    )
    parser.add_argument(
        "--overwrite", action="store_true", help="Replace an existing output dataset.",
    )
    return parser.parse_args()


def convert_to_grpo(input_file: Path, output_file: Path) -> tuple[int, int]:
    """Write valid GRPO rows and return ``(written, skipped)``."""
    if not input_file.is_file():
        raise FileNotFoundError(f"SFT dataset does not exist: {input_file}")
    written = skipped = 0
    with input_file.open("r", encoding="utf-8") as infile, output_file.open("x", encoding="utf-8") as outfile:
        for line_number, line in enumerate(infile, start=1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
                messages = item["messages"]
                if not isinstance(messages, list) or len(messages) != 3:
                    raise ValueError("expected exactly three messages")
                if [message.get("role") for message in messages] != ["system", "user", "assistant"]:
                    raise ValueError("expected system, user, assistant message roles")
                system, target, response = (message.get("content") for message in messages)
                if not all(isinstance(value, str) and value.strip() for value in (system, target, response)):
                    raise ValueError("all message contents must be non-empty strings")
                matches = ACTION_PATTERN.findall(response)
                if len(matches) != 1 or matches[0] not in VALID_ACTIONS:
                    raise ValueError("assistant response needs exactly one valid <action> tag")
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                skipped += 1
                print(f"Skipping line {line_number}: {exc}")
                continue

            # The current source has no conversation history.  Keep the
            # target marker explicit so future multi-turn examples can insert
            # a [Previous Comments] block immediately above it.
            prompt = (
                f"{system.strip()}\n\n"
                f"[Target Comment]\n{target.strip()}\n\n"
                "Provide your <reasoning> and <action>."
            )
            outfile.write(json.dumps({"prompt": prompt, "target_action": matches[0]}, ensure_ascii=False) + "\n")
            written += 1
    return written, skipped


def main() -> None:
    args = parse_args()
    if args.output_file.exists() and not args.overwrite:
        raise FileExistsError(f"Output already exists: {args.output_file}; pass --overwrite to replace it.")
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    written, skipped = convert_to_grpo(args.input_file, args.output_file)
    if not written:
        raise RuntimeError("No valid GRPO rows were created; the output file is empty.")
    print(f"Converted {written} rows; skipped {skipped} malformed rows.")
    print(f"Saved GRPO dataset to {args.output_file}")


if __name__ == "__main__":
    main()
