"""FastText-backed language routing for ContextGuard.

The FastText LID model identifies ISO languages, while script and statistical
signals identify romanised Hindi (Hinglish), which FastText cannot label.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import os
from pathlib import Path
import re
from typing import Optional, Protocol, Tuple


DEFAULT_FASTTEXT_MODEL = Path(
    os.environ.get("CONTEXTGUARD_FASTTEXT_MODEL", Path(__file__).with_name("models") / "lid.176.ftz")
)
DEVANAGARI_RE = re.compile(r"[\u0900-\u097F]")
LATIN_WORD_RE = re.compile(r"[A-Za-z]+")
TOKEN_RE = re.compile(r"[a-z]+")
VOWEL_RE = re.compile(r"[aeiou]")

# Short, high-signal function words are one signal only.  Character shape,
# token proportions and FastText's confidence are also required for routing.
ROMAN_HINDI_FUNCTION_WORDS = frozenset({
    "hai", "hain", "nahi", "nahin", "nhi", "kya", "kyu", "kyun", "kaise",
    "kaun", "kahan", "mera", "meri", "mere", "tera", "teri", "tere", "tum",
    "aap", "hum", "aur", "bhi", "bahut", "bohot", "mat", "raha", "rahi",
    "rahe", "kar", "karo", "karna", "kiya", "wala", "wali", "yaar",
})
HINDI_SUFFIXES = ("na", "ta", "ti", "te", "wala", "wali", "on", "ko", "se", "mein")


class FastTextModel(Protocol):
    def predict(self, text: str, k: int = 1) -> Tuple[list[str], list[float]]: ...


@dataclass(frozen=True)
class LanguageRoute:
    language: str  # english, hindi, hinglish, mixed, unknown, empty
    model: str  # english_bert or hingbert
    fasttext_language: Optional[str]
    fasttext_confidence: float
    confidence: float


@lru_cache(maxsize=1)
def load_fasttext_model(model_path: str | Path = DEFAULT_FASTTEXT_MODEL) -> FastTextModel:
    """Load the local LID model once; never download it implicitly."""
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError(
            f"FastText language model not found at {path}. Place lid.176.ftz there "
            "or set CONTEXTGUARD_FASTTEXT_MODEL to its local path."
        )
    try:
        import fasttext
    except ImportError as exc:
        raise RuntimeError("FastText is not installed. Install fasttext-wheel.") from exc
    return fasttext.load_model(str(path))


def _prediction(model: FastTextModel, text: str) -> tuple[Optional[str], float]:
    cleaned = text.replace("\n", " ")
    try:
        labels, scores = model.predict(cleaned, k=1)
    except ValueError as exc:
        # fasttext-wheel 0.9.2 calls np.array(..., copy=False), which fails
        # under NumPy 2.  Read the identical low-level prediction directly.
        if "Unable to avoid copy" not in str(exc) or not hasattr(model, "f"):
            raise
        predictions = model.f.predict(cleaned + "\n", 1, 0.0, "strict")
        scores, labels = zip(*predictions) if predictions else ([], [])
    if not labels or not scores:
        return None, 0.0
    return labels[0].replace("__label__", ""), float(scores[0])


def _roman_hindi_evidence(text: str) -> float:
    tokens = TOKEN_RE.findall(text.lower())
    if len(tokens) < 2:
        return 0.0
    function_ratio = sum(token in ROMAN_HINDI_FUNCTION_WORDS for token in tokens) / len(tokens)
    suffix_ratio = sum(token.endswith(HINDI_SUFFIXES) and len(token) >= 4 for token in tokens) / len(tokens)
    # Roman Hindi commonly has multiple short vowel-bearing tokens.  This is
    # deliberately weak evidence, preventing a keyword-only classifier.
    vowel_ratio = sum(bool(VOWEL_RE.search(token)) for token in tokens) / len(tokens)
    return min(1.0, 0.70 * function_ratio + 0.20 * suffix_ratio + 0.10 * vowel_ratio)


def detect_language(text: str, model: Optional[FastTextModel] = None) -> LanguageRoute:
    """Classify text for model routing without loading FastText more than once."""
    cleaned = " ".join((text or "").split())
    if not cleaned:
        return LanguageRoute("empty", "hingbert", None, 0.0, 1.0)

    if DEVANAGARI_RE.search(cleaned):
        latin_words = LATIN_WORD_RE.findall(cleaned)
        language = "mixed" if len(latin_words) >= 2 else "hindi"
        return LanguageRoute(language, "hingbert", "hi", 1.0, 1.0)

    predictor = model if model is not None else load_fasttext_model()
    ft_language, ft_confidence = _prediction(predictor, cleaned)
    roman_evidence = _roman_hindi_evidence(cleaned)
    latin_count = len(LATIN_WORD_RE.findall(cleaned))

    # FastText often calls Hinglish English/Hindi; route it to HingBERT only
    # when both its language signal and independent romanisation evidence fit.
    if latin_count >= 2 and roman_evidence >= 0.22 and ft_language in {"en", "hi", "ur"}:
        return LanguageRoute("hinglish", "hingbert", ft_language, ft_confidence,
                             max(roman_evidence, ft_confidence * 0.5))
    if ft_language == "hi" and ft_confidence >= 0.55:
        return LanguageRoute("hinglish", "hingbert", ft_language, ft_confidence, ft_confidence)
    if ft_language == "en" and ft_confidence >= 0.55:
        return LanguageRoute("english", "english_bert", ft_language, ft_confidence, ft_confidence)
    if ft_language in {"en", "hi", "ur"}:
        return LanguageRoute("mixed", "hingbert", ft_language, ft_confidence,
                             max(ft_confidence, roman_evidence))
    return LanguageRoute("unknown", "hingbert", ft_language, ft_confidence, ft_confidence)
