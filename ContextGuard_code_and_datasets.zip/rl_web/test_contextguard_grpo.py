#!/usr/bin/env python3
"""Run one local ContextGuard GRPO moderation inference.

The GRPO checkpoint is a LoRA delta trained *on top of* the v4 SFT LoRA, so
both adapters are loaded and active here.  It is not valid to load the GRPO
adapter by itself on the raw base model.
"""
from __future__ import annotations

import argparse
import os
import re
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


ROOT = Path(__file__).resolve().parent
BASE_MODEL = "mlabonne/Meta-Llama-3.1-8B-Instruct-abliterated"
DEFAULT_SFT_ADAPTER = ROOT / "contextguard_v4_llama31_8b_abliterated_sft"
DEFAULT_GRPO_ADAPTER = ROOT / "contextguard_grpo_outputs"
SYSTEM_PROMPT = (
    "You are ContextGuard, an AI moderation system. Analyze the Hinglish text and classify it into "
    "BENIGN, WARN, or ESCALATE. Do NOT use tool calls. Do NOT output <tool_call>. "
    "Provide your reasoning inside <reasoning> tags, followed by your decision inside <action> tags."
)
ACTION_PATTERN = re.compile(r"<action>\s*(BENIGN|WARN|ESCALATE)\s*</action>")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sft_adapter", type=Path, default=DEFAULT_SFT_ADAPTER)
    parser.add_argument("--grpo_adapter", type=Path, default=DEFAULT_GRPO_ADAPTER)
    parser.add_argument(
        "--context",
        default=(
            "User A: cricket match kaisa laga kal ka?\n"
            "User B: bkwas tha ekdum, umpire sold tha."
        ),
        help="Optional previous comments; use an empty string for no history.",
    )
    parser.add_argument(
        "--text",
        default="tu chup reh har bar rona shuru kar deta hai, tere ghar aake bat se marunga samjha na lawde.",
        help="Target comment to moderate.",
    )
    parser.add_argument("--max_new_tokens", type=int, default=512)
    return parser.parse_args()


def build_prompt(context: str, target: str) -> str:
    """Match the prompt-only GRPO training contract, adding history when present."""
    history = f"\n\n[Previous Comments]\n{context.strip()}" if context.strip() else ""
    return (
        f"{SYSTEM_PROMPT}{history}\n\n[Target Comment]\n{target.strip()}\n\n"
        "Provide your <reasoning> and <action>."
    )


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required for this 8B 4-bit inference launcher.")
    for label, directory in (("SFT", args.sft_adapter), ("GRPO", args.grpo_adapter)):
        if not (directory / "adapter_config.json").is_file():
            raise FileNotFoundError(f"{label} adapter missing adapter_config.json: {directory}")

    token = os.environ.get("HF_TOKEN")
    compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    print("Loading 4-bit base model and SFT + GRPO adapters...")
    tokenizer = AutoTokenizer.from_pretrained(args.grpo_adapter, use_fast=True, token=token)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=compute_dtype,
        ),
        torch_dtype=compute_dtype,
        device_map={"": 0},
        token=token,
    )
    model = PeftModel.from_pretrained(model, args.sft_adapter, adapter_name="default")
    model.load_adapter(args.grpo_adapter, adapter_name="grpo")
    # PeftModel's public method accepts one adapter, while the underlying LoRA
    # tuner accepts a list.  GRPO was trained with this exact active stack.
    model.base_model.set_adapter(["default", "grpo"], inference_mode=True)
    model.eval()

    prompt = build_prompt(args.context, args.text)
    device = model.get_input_embeddings().weight.device
    inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False).to(device)
    print("\nGenerating evaluation...\n")
    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=args.max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    response = tokenizer.decode(outputs[0, inputs["input_ids"].shape[1]:], skip_special_tokens=False).strip()
    match = ACTION_PATTERN.search(response)
    print("--- ContextGuard Output ---")
    print(response)
    print(f"\nParsed action: {match.group(1) if match else 'MALFORMED / NOT FOUND'}")


if __name__ == "__main__":
    main()
