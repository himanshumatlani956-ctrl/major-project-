"""Single-load inference service for ContextGuard language routing."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Mapping, Optional

import torch

from content_classifier import ContentClassificationResult, ContentTypeClassifier
from language_router import LanguageRoute, detect_language

PROJECT_ROOT = Path(__file__).resolve().parent.parent
HINGBERT_WEIGHTS = Path(__file__).with_name("hingbert_weights") / "hingbert_best.pt"
HINGBERT_TOKENIZER = Path(__file__).with_name("hingbert_weights") / "tokenizer"
ENGLISH_WEIGHTS = Path(__file__).with_name("contextguard_weights") / "english_bert" / "english_bert.pt"


@dataclass(frozen=True)
class ToxicityResult:
    prediction: str
    confidence: float
    toxicity_score: float
    detected_language: str
    language_confidence: float
    model_used: str
    content: ContentClassificationResult
    # Actual classifier softmax outputs, retained as GRPO evidence rather than
    # being combined into a heuristic final decision.
    action_probabilities: Optional[Mapping[str, float]] = None


class ToxicityService:
    """Lazily loads each existing fine-tuned classifier once per process."""

    def __init__(self, device: Optional[str] = None, fasttext_model=None, content_classifier=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.fasttext_model = fasttext_model
        self._english = None
        self._hingbert = None
        # BART is lazy; content failures remain metadata and cannot alter
        # toxicity availability or the resulting toxicity score.
        self.content_classifier = content_classifier or ContentTypeClassifier(device=self.device)

    def _english_model(self):
        if self._english is None:
            if not ENGLISH_WEIGHTS.is_file():
                raise FileNotFoundError(f"English model checkpoint missing: {ENGLISH_WEIGHTS}")
            from english_bert import EnglishModerator
            self._english = EnglishModerator(self.device)
        return self._english

    def _hingbert_model(self):
        if self._hingbert is None:
            if not HINGBERT_WEIGHTS.is_file() or not HINGBERT_TOKENIZER.is_dir():
                raise FileNotFoundError(
                    "HingBERT checkpoint or tokenizer missing. Expected "
                    f"{HINGBERT_WEIGHTS} and {HINGBERT_TOKENIZER}."
                )
            if str(PROJECT_ROOT) not in sys.path:
                sys.path.insert(0, str(PROJECT_ROOT))
            from hinglish import HingBertModerator
            self._hingbert = HingBertModerator(
                weights_path=str(HINGBERT_WEIGHTS), tokenizer_path=str(HINGBERT_TOKENIZER),
                device=self.device,
            )
        return self._hingbert

    def route(self, text: str) -> LanguageRoute:
        return detect_language(text, model=self.fasttext_model)

    def classify(self, text: str, *, hingbert_text: Optional[str] = None) -> ToxicityResult:
        content = self.content_classifier.classify(text)
        route = self.route(text)
        if route.language == "empty":
            return ToxicityResult("BENIGN", 1.0, 0.0, "empty", 1.0, "none", content, None)

        if route.model == "english_bert":
            probs = self._english_model().predict_probs([text])[0]
            label_id = int(probs.argmax())
            labels = ("BENIGN", "WARN", "ESCALATE")
            score = float(0.5 * probs[1] + probs[2])
            return ToxicityResult(labels[label_id], float(probs[label_id]), score,
                                  route.language, route.confidence, "distilbert_english", content,
                                  {label: float(probs[index]) for index, label in enumerate(labels)})

        label, score, probs = self._hingbert_model().predict([hingbert_text or text])[0]
        return ToxicityResult(label, float(max(probs)), float(score), route.language,
                              route.confidence, "hingbert", content,
                              {name: float(probs[index]) for index, name in enumerate(("BENIGN", "WARN", "ESCALATE"))})
