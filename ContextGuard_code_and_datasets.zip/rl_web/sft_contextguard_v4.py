"""QLoRA supervised fine-tuning for the ContextGuard v4 chat dataset.

The dataset is JSONL with ``system``, ``user``, and ``assistant`` messages.
Only the assistant response contributes to loss, so the model learns the
moderation answer rather than copying the instruction or input text.
"""
from __future__ import annotations

import argparse
import json
import os
import random
from pathlib import Path

import torch
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import (
    AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, Trainer,
    TrainingArguments, set_seed,
)
from transformers.trainer_utils import get_last_checkpoint


ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = "mlabonne/Meta-Llama-3.1-8B-Instruct-abliterated"
DEFAULT_DATASET = ROOT / "contextguard_sft_dataset_v4_ready.jsonl"
DEFAULT_OUTPUT = ROOT / "contextguard_v4_llama31_8b_abliterated_sft"


class AssistantOnlyCollator:
    """Pads pre-tokenized examples; labels already mask non-assistant tokens."""

    def __init__(self, pad_token_id: int):
        self.pad_token_id = pad_token_id

    def __call__(self, features):
        max_length = max(len(feature["input_ids"]) for feature in features)
        batch = {"input_ids": [], "attention_mask": [], "labels": []}
        for feature in features:
            padding = max_length - len(feature["input_ids"])
            batch["input_ids"].append(feature["input_ids"] + [self.pad_token_id] * padding)
            batch["attention_mask"].append(feature["attention_mask"] + [0] * padding)
            batch["labels"].append(feature["labels"] + [-100] * padding)
        return {name: torch.tensor(values, dtype=torch.long) for name, values in batch.items()}


def read_rows(dataset_path: Path) -> list[dict]:
    rows = []
    with dataset_path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            record = json.loads(line)
            messages = record.get("messages")
            if not isinstance(messages, list) or len(messages) != 3:
                raise ValueError(f"Line {line_number}: expected exactly system, user, assistant messages.")
            if [message.get("role") for message in messages] != ["system", "user", "assistant"]:
                raise ValueError(f"Line {line_number}: expected roles system, user, assistant in that order.")
            if not all(isinstance(message.get("content"), str) and message["content"].strip() for message in messages):
                raise ValueError(f"Line {line_number}: every message must have non-empty text content.")
            rows.append({"messages": messages})
    if not rows:
        raise ValueError("Dataset has no rows.")
    return rows


def split_rows(rows: list[dict], validation_fraction: float, seed: int) -> tuple[list[dict], list[dict]]:
    """Deterministic split, stratified by the final ContextGuard action."""
    groups: dict[str, list[dict]] = {}
    for row in rows:
        answer = row["messages"][-1]["content"]
        action = next((label for label in ("BENIGN", "WARN", "ESCALATE") if f"<action>{label}</action>" in answer), None)
        if action is None:
            raise ValueError("Each assistant message must contain one ContextGuard <action> label.")
        groups.setdefault(action, []).append(row)
    train, validation = [], []
    rng = random.Random(seed)
    for examples in groups.values():
        rng.shuffle(examples)
        validation_count = max(1, round(len(examples) * validation_fraction))
        validation.extend(examples[:validation_count])
        train.extend(examples[validation_count:])
    rng.shuffle(train)
    rng.shuffle(validation)
    return train, validation


def tokenize_rows(rows: list[dict], tokenizer, max_length: int) -> Dataset:
    tokenized = []
    for index, row in enumerate(rows):
        messages = row["messages"]
        # This includes the template's assistant-turn marker before the completion.
        prompt = tokenizer.apply_chat_template(messages[:-1], tokenize=False, add_generation_prompt=True)
        completion = messages[-1]["content"] + tokenizer.eos_token
        prompt_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
        completion_ids = tokenizer(completion, add_special_tokens=False)["input_ids"]
        if len(completion_ids) >= max_length:
            raise ValueError(f"Example {index} assistant response is longer than max_length={max_length}.")
        # Keep every target token; if necessary discard only oldest context tokens.
        prompt_ids = prompt_ids[-(max_length - len(completion_ids)):]
        input_ids = prompt_ids + completion_ids
        tokenized.append({
            "input_ids": input_ids,
            "attention_mask": [1] * len(input_ids),
            "labels": [-100] * len(prompt_ids) + completion_ids,
        })
    return Dataset.from_list(tokenized)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name_or_path", default=DEFAULT_MODEL)
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output_dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--resume_from_checkpoint", type=Path,
        help="Checkpoint directory to resume from. Defaults to the newest checkpoint in output_dir.",
    )
    parser.add_argument("--max_length", type=int, default=2048)
    parser.add_argument("--epochs", type=float, default=3)
    parser.add_argument("--learning_rate", type=float, default=2e-4)
    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--validation_fraction", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=20261016)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("This QLoRA launcher requires an NVIDIA CUDA GPU.")
    if not args.dataset.is_file():
        raise FileNotFoundError(args.dataset)
    if not 0 < args.validation_fraction < 1:
        raise ValueError("validation_fraction must be between 0 and 1.")

    set_seed(args.seed)
    rows = read_rows(args.dataset)
    train_rows, validation_rows = split_rows(rows, args.validation_fraction, args.seed)
    compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    # Hugging Face Hub reads HF_TOKEN too, but passing it explicitly keeps both
    # tokenizer and model downloads authenticated when a gated model is used.
    hf_token = os.environ.get("HF_TOKEN")
    tokenizer = AutoTokenizer.from_pretrained(args.model_name_or_path, use_fast=True, token=hf_token)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    quantization = BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=compute_dtype,
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_name_or_path, quantization_config=quantization,
        torch_dtype=compute_dtype, device_map={"": 0}, token=hf_token,
    )
    model.config.pad_token_id = tokenizer.pad_token_id
    model.config.use_cache = False
    model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)
    model = get_peft_model(model, LoraConfig(
        r=16, lora_alpha=32, lora_dropout=0.05, bias="none",
        task_type="CAUSAL_LM", target_modules="all-linear",
    ))

    train_dataset = tokenize_rows(train_rows, tokenizer, args.max_length)
    validation_dataset = tokenize_rows(validation_rows, tokenizer, args.max_length)
    output_dir = str(args.output_dir)
    checkpoint = str(args.resume_from_checkpoint) if args.resume_from_checkpoint else (
        get_last_checkpoint(output_dir) if args.output_dir.exists() else None
    )
    if checkpoint is not None and not (Path(checkpoint) / "trainer_state.json").is_file():
        raise FileNotFoundError(f"Not a Trainer checkpoint: {checkpoint}")
    if args.output_dir.exists() and any(args.output_dir.iterdir()) and checkpoint is None:
        raise FileExistsError(f"Output exists but has no resumable checkpoint: {args.output_dir}")

    trainer = Trainer(
        model=model,
        args=TrainingArguments(
            output_dir=output_dir, num_train_epochs=args.epochs, learning_rate=args.learning_rate,
            per_device_train_batch_size=args.batch_size, per_device_eval_batch_size=args.batch_size,
            gradient_accumulation_steps=args.gradient_accumulation_steps,
            gradient_checkpointing=True, bf16=compute_dtype is torch.bfloat16,
            fp16=compute_dtype is torch.float16, logging_steps=5, eval_strategy="epoch",
            save_strategy="epoch", save_total_limit=2, load_best_model_at_end=True,
            metric_for_best_model="eval_loss", greater_is_better=False, report_to="none",
            seed=args.seed, data_seed=args.seed, remove_unused_columns=False,
        ),
        train_dataset=train_dataset, eval_dataset=validation_dataset,
        data_collator=AssistantOnlyCollator(tokenizer.pad_token_id),
    )
    trainer.train(resume_from_checkpoint=checkpoint)
    trainer.save_model(output_dir)  # This saves the small LoRA adapter, not another 8B base model.
    tokenizer.save_pretrained(output_dir)
    (args.output_dir / "run_metadata.json").write_text(json.dumps({
        "base_model": args.model_name_or_path, "dataset": str(args.dataset),
        "train_examples": len(train_dataset), "validation_examples": len(validation_dataset),
        "max_length": args.max_length, "seed": args.seed,
    }, indent=2) + "\n", encoding="utf-8")
    print(f"Saved LoRA adapter to {args.output_dir}")


if __name__ == "__main__":
    main()
