"""
english_bert.py  -  English moderation model for ContextGuard (VS Code version)

* Same architecture as your Colab notebook (DistilBERT + 3-class head, top layers unfrozen)
* Weights are saved INSIDE  ./contextguard_weights/english_bert/   (no Google Drive)
* Re-running with --resume keeps improving the saved weights
* EnglishModerator is imported by 4_prodgate.py so English + Hinglish work together

Expected data layout (copy your CSVs out of Drive once):
    data/english/train.csv       columns: text,label   (0=BENIGN 1=WARN 2=ESCALATE)
    data/english/val.csv
    data/english/test.csv
    data/stress_test.csv         columns: text,label,language   (optional)

Train :  python english_bert.py --epochs 5
Resume:  python english_bert.py --epochs 3 --resume
"""
import os
import json
import argparse

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import f1_score, classification_report
from sklearn.model_selection import train_test_split
from transformers import DistilBertTokenizerFast, DistilBertModel

BASE_MODEL = "distilbert-base-uncased"
WEIGHTS_ROOT = "./contextguard_weights"
WEIGHTS_DIR = os.path.join(WEIGHTS_ROOT, "english_bert")   # <- everything is saved here
WEIGHTS_FILE = os.path.join(WEIGHTS_DIR, "english_bert.pt")
DATA_DIR = os.path.join("data", "english")
STRESS_PATH = os.path.join("data", "stress_test.csv")
LABELS = ["BENIGN", "WARN", "ESCALATE"]


# ---------------------------------------------------------------
# Model (identical to the notebook)
# ---------------------------------------------------------------
class ModerationClassifier(nn.Module):
    def __init__(self, num_classes=3, unfreeze_from_layer=4):
        super().__init__()
        self.distilbert = DistilBertModel.from_pretrained(BASE_MODEL)

        for p in self.distilbert.parameters():
            p.requires_grad = False
        for i, layer in enumerate(self.distilbert.transformer.layer):
            if i >= unfreeze_from_layer:
                for p in layer.parameters():
                    p.requires_grad = True

        self.classifier = nn.Sequential(
            nn.Linear(768, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes),
        )

    def forward(self, input_ids, attention_mask):
        out = self.distilbert(input_ids=input_ids, attention_mask=attention_mask)
        return self.classifier(out.last_hidden_state[:, 0, :])


# ---------------------------------------------------------------
# Data
# ---------------------------------------------------------------
class TextDataset(Dataset):
    def __init__(self, df):
        self.texts = df["text"].astype(str).tolist()
        self.labels = df["label"].astype(int).tolist()

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, i):
        return self.texts[i], self.labels[i]


def make_loader(df, tokenizer, batch_size, shuffle, max_len=128):
    def collate(batch):  # dynamic padding = faster than padding to 128 every time
        texts, labels = zip(*batch)
        enc = tokenizer(list(texts), padding=True, truncation=True,
                        max_length=max_len, return_tensors="pt")
        enc["labels"] = torch.tensor(labels, dtype=torch.long)
        return enc
    return DataLoader(TextDataset(df), batch_size=batch_size, shuffle=shuffle, collate_fn=collate)


def read_split(path):
    df = pd.read_csv(path).dropna(subset=["text", "label"]).reset_index(drop=True)
    return df



# ---------------------------------------------------------------
# Data sanity tools
# ---------------------------------------------------------------
def check_data(dfs):
    """Print label mix + sample texts per split, and warn if train/val disagree."""
    dist = {}
    for name, d in dfs.items():
        p = d["label"].value_counts(normalize=True).reindex([0, 1, 2]).fillna(0)
        dist[name] = p
        print(f"\n[{name}] n={len(d)} | " + "  ".join(f"{LABELS[i]}={p[i]:.2f}" for i in range(3)))
        for lab in (0, 1, 2):
            sub = d[d["label"] == lab]
            if len(sub):
                ex = sub["text"].astype(str).sample(min(2, len(sub)), random_state=1).str[:80].tolist()
                print(f"   {LABELS[lab]:9s}e.g. " + " || ".join(ex))
    if "train" in dist and "val" in dist:
        gap = (dist["train"] - dist["val"]).abs().max()
        if gap > 0.10:
            print(f"\n[WARNING] train/val label mix differs by {gap:.2f}. "
                  "Use --resplit (or fix the label mapping) before trusting any scores.")


def parse_remap(s):
    """'0:1,1:0' -> {0:1, 1:0}"""
    return {int(a): int(b) for a, b in (x.split(":") for x in s.split(","))} if s else {}


def resplit(train_df, val_df, seed=42):
    """Merge train+val, drop duplicate texts, make a stratified 90/10 split."""
    allf = pd.concat([train_df, val_df]).drop_duplicates("text").reset_index(drop=True)
    tr, va = train_test_split(allf, test_size=0.1, stratify=allf["label"], random_state=seed)
    return tr.reset_index(drop=True), va.reset_index(drop=True)

# ---------------------------------------------------------------
# Train / eval helpers
# ---------------------------------------------------------------
@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    total, preds_all, labels_all = 0.0, [], []
    for b in loader:
        ids, mask, y = b["input_ids"].to(device), b["attention_mask"].to(device), b["labels"].to(device)
        logits = model(ids, mask)
        total += criterion(logits, y).item()
        preds_all.extend(logits.argmax(1).cpu().tolist())
        labels_all.extend(y.cpu().tolist())
    f1 = f1_score(labels_all, preds_all, average="macro")
    return total / len(loader), f1, labels_all, preds_all


def save_weights(model, tokenizer, meta):
    os.makedirs(WEIGHTS_DIR, exist_ok=True)
    torch.save(model.state_dict(), WEIGHTS_FILE)
    tokenizer.save_pretrained(WEIGHTS_DIR)
    with open(os.path.join(WEIGHTS_DIR, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)


def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    train_df = read_split(os.path.join(args.data_dir, "train.csv"))
    val_df = read_split(os.path.join(args.data_dir, "val.csv"))
    test_path = os.path.join(args.data_dir, "test.csv")
    test_df = read_split(test_path) if os.path.exists(test_path) else None

    # optional: fix a wrong label mapping in one file, e.g. --remap_val "0:2,2:0"
    if args.remap_val:
        val_df["label"] = val_df["label"].map(lambda x: parse_remap(args.remap_val).get(int(x), int(x)))
    if args.remap_test and test_df is not None:
        test_df["label"] = test_df["label"].map(lambda x: parse_remap(args.remap_test).get(int(x), int(x)))

    # optional: rebuild train/val so both have the same label mix
    if args.resplit:
        train_df, val_df = resplit(train_df, val_df)

    # never let test sentences leak into training
    if test_df is not None:
        before = len(train_df)
        train_df = train_df[~train_df["text"].isin(test_df["text"])].reset_index(drop=True)
        val_df = val_df[~val_df["text"].isin(test_df["text"])].reset_index(drop=True)
        if len(train_df) != before:
            print(f"Removed {before - len(train_df)} train rows that also appear in test")

    splits = {"train": train_df, "val": val_df}
    if test_df is not None:
        splits["test"] = test_df
    check_data(splits)
    if args.check:
        return   # inspect only, no training

    tokenizer = DistilBertTokenizerFast.from_pretrained(BASE_MODEL)
    train_loader = make_loader(train_df, tokenizer, args.batch_size, True)
    val_loader = make_loader(val_df, tokenizer, args.batch_size, False)

    model = ModerationClassifier().to(device)
    best_f1 = 0.0
    if args.resume and os.path.exists(WEIGHTS_FILE):
        model.load_state_dict(torch.load(WEIGHTS_FILE, map_location=device))
        meta_path = os.path.join(WEIGHTS_DIR, "meta.json")
        if os.path.exists(meta_path):
            best_f1 = json.load(open(meta_path)).get("best_val_f1", 0.0)
        print(f"Resumed from {WEIGHTS_FILE} (best F1 so far: {best_f1:.4f})")

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable params: {trainable:,}")

    criterion = nn.CrossEntropyLoss(weight=torch.tensor([1.5, 0.6, 1.2]).to(device))
    # Fresh head can take a high LR; pretrained transformer layers need a gentle one.
    optimizer = AdamW([
        {"params": model.classifier.parameters(), "lr": args.head_lr},
        {"params": [p for p in model.distilbert.parameters() if p.requires_grad], "lr": args.bert_lr},
    ], weight_decay=0.01)

    use_amp = device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    for epoch in range(args.epochs):
        model.train()
        total_loss, correct, n = 0.0, 0, 0
        for b in train_loader:
            ids, mask, y = b["input_ids"].to(device), b["attention_mask"].to(device), b["labels"].to(device)
            optimizer.zero_grad()
            with torch.autocast(device_type=device.type, enabled=use_amp):
                logits = model(ids, mask)
                loss = criterion(logits, y)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()

            total_loss += loss.item()
            correct += (logits.argmax(1) == y).sum().item()
            n += y.size(0)

        val_loss, val_f1, _, _ = evaluate(model, val_loader, criterion, device)
        print(f"Epoch {epoch+1}/{args.epochs} | train loss {total_loss/len(train_loader):.4f} "
              f"acc {correct/n:.4f} | val loss {val_loss:.4f} F1 {val_f1:.4f}")

        if val_f1 > best_f1:
            best_f1 = val_f1
            save_weights(model, tokenizer, {"base_model": BASE_MODEL, "best_val_f1": best_f1,
                                            "labels": LABELS})
            print(f"  saved best model -> {WEIGHTS_FILE} (F1 {best_f1:.4f})")

    # ---- final reports with the best weights ----
    model.load_state_dict(torch.load(WEIGHTS_FILE, map_location=device))
    report_split("VAL", val_df, model, tokenizer, criterion, device, args.batch_size)

    if test_df is not None:
        report_split("TEST", test_df, model, tokenizer, criterion, device, args.batch_size)

    if os.path.exists(args.stress_path):
        s = pd.read_csv(args.stress_path).dropna(subset=["text", "label"])
        if "language" in s.columns:
            s = s[s["language"] == "english"]
        report_split("STRESS (english)", s.reset_index(drop=True), model, tokenizer,
                     criterion, device, args.batch_size)


def report_split(name, df, model, tokenizer, criterion, device, batch_size):
    loader = make_loader(df, tokenizer, batch_size, False)
    _, _, y, p = evaluate(model, loader, criterion, device)
    print(f"\n===== {name} =====")
    print(classification_report(y, p, labels=[0, 1, 2], target_names=LABELS, zero_division=0))


# ---------------------------------------------------------------
# Inference class used by the production gateway
# ---------------------------------------------------------------
class EnglishModerator:
    """Loads weights from ./contextguard_weights/english_bert/ and scores text in [0,1]."""

    def __init__(self, device=None):
        if not os.path.exists(WEIGHTS_FILE):
            raise FileNotFoundError(f"{WEIGHTS_FILE} not found. Run: python english_bert.py")
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = DistilBertTokenizerFast.from_pretrained(WEIGHTS_DIR)
        self.model = ModerationClassifier().to(self.device)
        self.model.load_state_dict(torch.load(WEIGHTS_FILE, map_location=self.device))
        self.model.eval()

    @torch.no_grad()
    def predict_probs(self, texts):
        enc = self.tokenizer(texts, padding=True, truncation=True, max_length=128,
                             return_tensors="pt").to(self.device)
        logits = self.model(enc["input_ids"], enc["attention_mask"])
        return torch.softmax(logits, dim=-1).cpu().numpy()      # (N, 3)

    def predict_score(self, texts):
        """Expected severity on the SAME 0 / 0.5 / 1 scale as the Hinglish regressor."""
        p = self.predict_probs(texts)
        return (0.5 * p[:, 1] + 1.0 * p[:, 2]).tolist()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--head_lr", type=float, default=2e-4)
    ap.add_argument("--bert_lr", type=float, default=2e-5)
    ap.add_argument("--data_dir", default=DATA_DIR)
    ap.add_argument("--stress_path", default=STRESS_PATH)
    ap.add_argument("--resume", action="store_true", help="continue from saved weights")
    ap.add_argument("--check", action="store_true", help="only print data diagnostics, no training")
    ap.add_argument("--resplit", action="store_true", help="merge train+val and re-split (stratified)")
    ap.add_argument("--remap_val", default="", help='fix val labels, e.g. "0:2,2:0"')
    ap.add_argument("--remap_test", default="", help='fix test labels, e.g. "0:2,2:0"')
    train(ap.parse_args())