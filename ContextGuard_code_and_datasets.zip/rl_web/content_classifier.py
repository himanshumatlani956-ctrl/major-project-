"""Lazy zero-shot content classification for ContextGuard.

Content type is deliberately separate from toxicity: its configurable weight is
metadata for a future, evaluated policy and does not alter moderation scores or
GRPO rewards.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import os
from typing import Any, Callable, Mapping, Optional

import torch
from transformers import pipeline


MODEL_NAME = "facebook/bart-large-mnli"
CONTENT_WEIGHTS: Mapping[str, float] = {
    "political": 1.5, "news": 1.3, "humor_meme": 0.8, "rant": 1.0, "casual": 0.7,
}
CONTENT_LABELS: Mapping[str, str] = {
    "political": "political discussion or commentary",
    "news": "news reporting or current-events update",
    "humor_meme": "humor, joke, or internet meme",
    "rant": "rant, complaint, or frustrated opinion",
    "casual": "casual conversation or social chat",
}


@dataclass(frozen=True)
class ContentClassificationResult:
    """A content signal, or an explicit state when no safe signal is available."""
    content_type: Optional[str]
    confidence: Optional[float]
    weight: Optional[float]
    status: str  # ok, uncertain, empty, invalid_input, unavailable
    error: Optional[str] = None


def _confidence_threshold() -> float:
    try:
        threshold = float(os.environ.get("CONTEXTGUARD_CONTENT_CONFIDENCE_THRESHOLD", "0"))
    except ValueError:
        return 0.0
    return min(1.0, max(0.0, threshold))


class ContentTypeClassifier:
    """Loads BART once on first valid inference, not when this module imports."""
    def __init__(self, *, device: Optional[str] = None, confidence_threshold: Optional[float] = None,
                 pipeline_factory: Callable[..., Any] = pipeline,
                 weights: Mapping[str, float] = CONTENT_WEIGHTS) -> None:
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.confidence_threshold = _confidence_threshold() if confidence_threshold is None else confidence_threshold
        self.pipeline_factory = pipeline_factory
        self.weights = dict(weights)
        missing = set(CONTENT_LABELS) - set(self.weights)
        if missing:
            raise ValueError(f"Missing content weights for: {', '.join(sorted(missing))}")
        self._classifier = None

    def _load(self):
        if self._classifier is None:
            self._classifier = self.pipeline_factory(
                "zero-shot-classification", model=MODEL_NAME, device=0 if self.device == "cuda" else -1
            )
        return self._classifier

    def classify(self, text: object, platform: Optional[str] = None) -> ContentClassificationResult:
        """Classify one primary content category; platform is currently unused."""
        del platform
        if not isinstance(text, str):
            return ContentClassificationResult(None, None, None, "invalid_input", "text must be a string")
        cleaned = " ".join(text.split())
        if not cleaned:
            return ContentClassificationResult(None, None, None, "empty")
        try:
            output = self._load()(cleaned, candidate_labels=list(CONTENT_LABELS.values()), multi_label=False)
            labels, scores = output.get("labels", []), output.get("scores", [])
            if not labels or not scores:
                raise ValueError("zero-shot model returned no labels or scores")
            predicted_label, score = labels[0], float(scores[0])
            category = next((key for key, label in CONTENT_LABELS.items() if label == predicted_label), None)
            if category is None:
                raise ValueError(f"zero-shot model returned an unknown label: {predicted_label!r}")
            if score < self.confidence_threshold:
                return ContentClassificationResult(None, score, None, "uncertain")
            return ContentClassificationResult(category, score, self.weights[category], "ok")
        except Exception as exc:
            # Never invent a category/weight after a loading or inference error.
            return ContentClassificationResult(None, None, None, "unavailable", str(exc))


@lru_cache(maxsize=1)
def get_content_classifier() -> ContentTypeClassifier:
    """Return the process-wide lazy classifier instance."""
    return ContentTypeClassifier()


def classify_content_type(text, platform=None) -> ContentClassificationResult:
    """Classify content using the process-wide lazy BART classifier."""
    return get_content_classifier().classify(text, platform=platform)
